import React from 'react';

const Button = ({ children, onClick, type = 'button', variant = 'primary', className = '', disabled = false }) => {
  const variants = {
    primary: 'bg-red-600 hover:bg-red-700 text-white',
    secondary: 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200',
    outline: 'border border-red-600 text-red-600 hover:bg-red-600 hover:text-white',
    airtel: 'bg-red-600 hover:bg-red-700 text-white',
    jio: 'bg-blue-600 hover:bg-blue-700 text-white',
    bsnl: 'bg-green-600 hover:bg-green-700 text-white'
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`px-4 py-2 rounded font-medium transition-colors ${variants[variant]} ${className} ${
        disabled ? 'opacity-50 cursor-not-allowed' : ''
      }`}
    >
      {children}
    </button>
  );
};

export default Button;
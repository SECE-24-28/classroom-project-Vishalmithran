import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const Navbar = () => {
  const { isLoggedIn, user, logout, isAdmin } = useApp();

  return (
    <nav className="bg-gradient-to-r from-red-600 to-red-800 shadow-lg">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-xl font-bold text-white">
            💜 QuickRecharge
          </Link>
          
          <div className="flex items-center space-x-4">
            {!isLoggedIn && (
              <>
                <Link to="/" className="text-red-100 hover:text-white">About</Link>
                <Link
                  to="/login"
                  className="bg-red-700 hover:bg-red-900 px-3 py-1 rounded text-white"
                >
                  Login
                </Link>
              </>
            )}
            {isLoggedIn && (
              <>
                <Link to="/mobile-entry" className="text-red-100 hover:text-white">Recharge</Link>
                <Link to="/history" className="text-red-100 hover:text-white">History</Link>
                {isAdmin && (
                  <Link to="/admin" className="text-red-100 hover:text-white">Admin</Link>
                )}
                <span className="text-red-100">Hi, {user?.email?.split('@')[0]}</span>
                <button
                  onClick={logout}
                  className="bg-red-700 hover:bg-red-900 px-3 py-1 rounded text-white"
                >
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

const About = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-200">
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-indigo-900 mb-6">💜 QuickRecharge</h1>
            <p className="text-2xl text-indigo-700 mb-8">Your trusted mobile recharge partner</p>
            <Button 
              onClick={() => navigate('/login')}
              className="text-xl px-8 py-4 bg-indigo-600 hover:bg-indigo-700"
            >
              🚀 Start Recharge
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-indigo-800 mb-4">Our Mission</h2>
              <p className="text-gray-700 leading-relaxed">
                To provide the fastest, most reliable mobile recharge service with 
                competitive prices and excellent customer support. We make mobile 
                recharging simple and convenient for everyone.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-indigo-800 mb-4">Why Choose Us?</h2>
              <ul className="text-gray-700 space-y-2">
                <li>✅ Instant recharge processing</li>
                <li>✅ 24/7 customer support</li>
                <li>✅ Secure payment gateway</li>
                <li>✅ Best prices guaranteed</li>
                <li>✅ All major operators supported</li>
              </ul>
            </div>
          </div>

          <div className="bg-gradient-to-r from-violet-500 to-purple-600 rounded-lg shadow-lg p-8 text-white text-center">
            <h2 className="text-3xl font-bold mb-6">📡 Supported Operators</h2>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-red-500 rounded-lg p-6 hover:bg-red-600 transition-colors">
                <h3 className="text-xl font-bold mb-2">📶 Airtel</h3>
                <p className="text-sm">Fast & Reliable Network</p>
              </div>
              <div className="bg-blue-500 rounded-lg p-6 hover:bg-blue-600 transition-colors">
                <h3 className="text-xl font-bold mb-2">📱 Jio</h3>
                <p className="text-sm">Digital India Leader</p>
              </div>
              <div className="bg-green-500 rounded-lg p-6 hover:bg-green-600 transition-colors">
                <h3 className="text-xl font-bold mb-2">🌐 BSNL</h3>
                <p className="text-sm">Trusted Government Network</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';
import InputField from '../components/InputField';
import { operators } from '../data/plans';

const Home = () => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [selectedOperator, setSelectedOperator] = useState('');
  const navigate = useNavigate();

  const detectOperator = (number) => {
    if (number.length >= 2) {
      const prefix = number.substring(0, 2);
      const operator = operators.find(op => op.prefixes.includes(prefix));
      if (operator) setSelectedOperator(operator.id);
    }
  };

  const handleMobileChange = (e) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 10);
    setMobileNumber(value);
    detectOperator(value);
  };

  const handleRecharge = () => {
    if (mobileNumber.length === 10 && selectedOperator) {
      navigate('/plans', { state: { mobileNumber, operator: selectedOperator } });
    } else {
      alert('Please enter a valid 10-digit mobile number');
    }
  };

  const getOperatorColor = (operatorId) => {
    const operator = operators.find(op => op.id === operatorId);
    return operator ? operator.color : 'violet';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-100 to-purple-200">
      {/* Hero Section */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold text-violet-900 mb-6">
            🚀 Quick Mobile Recharge
          </h1>
          <p className="text-xl text-violet-700 mb-12">
            Instant recharge for all major operators
          </p>
          
          <div className="max-w-md mx-auto bg-white rounded-xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-violet-800 mb-6">Start Recharge</h2>
            
            <InputField
              label="Mobile Number"
              value={mobileNumber}
              onChange={handleMobileChange}
              placeholder="Enter 10-digit number"
              maxLength={10}
              className="text-lg"
            />
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Operator
              </label>
              <div className="grid grid-cols-3 gap-2">
                {operators.map(op => (
                  <button
                    key={op.id}
                    onClick={() => setSelectedOperator(op.id)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedOperator === op.id
                        ? `border-${op.color}-500 bg-${op.color}-50`
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className={`font-bold text-${op.color}-600`}>{op.name}</div>
                  </button>
                ))}
              </div>
            </div>
            
            <Button 
              onClick={handleRecharge} 
              className={`w-full text-lg py-3 ${
                selectedOperator 
                  ? `bg-${getOperatorColor(selectedOperator)}-600 hover:bg-${getOperatorColor(selectedOperator)}-700`
                  : ''
              }`}
            >
              Continue to Plans →
            </Button>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-violet-900 mb-12">Why Choose Us?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-bold text-violet-800 mb-2">Instant Recharge</h3>
              <p className="text-gray-600">Get your recharge done in seconds</p>
            </div>
            <div className="text-center p-6">
              <div className="text-4xl mb-4">🔒</div>
              <h3 className="text-xl font-bold text-violet-800 mb-2">Secure Payment</h3>
              <p className="text-gray-600">100% safe and secure transactions</p>
            </div>
            <div className="text-center p-6">
              <div className="text-4xl mb-4">💰</div>
              <h3 className="text-xl font-bold text-violet-800 mb-2">Best Prices</h3>
              <p className="text-gray-600">Competitive rates for all plans</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
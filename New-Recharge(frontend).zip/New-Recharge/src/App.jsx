import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Layout from './components/Layout';
import About from './pages/About';
import Login from './pages/Login';
import MobileEntry from './pages/MobileEntry';
import Plans from './pages/Plans';
import Payment from './pages/Payment';
import Success from './pages/Success';
import History from './pages/History';
import Admin from './pages/Admin';

function App() {
  return (
    <AppProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<About />} />
            <Route path="/login" element={<Login />} />
            <Route path="/mobile-entry" element={<MobileEntry />} />
            <Route path="/plans" element={<Plans />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/success" element={<Success />} />
            <Route path="/history" element={<History />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </Layout>
      </Router>
    </AppProvider>
  );
}

export default App;
export const rechargePlans = [
  {
    id: 1,
    price: 199,
    validity: '28 days',
    data: '2GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'airtel',
    popular: true
  },
  {
    id: 2,
    price: 299,
    validity: '28 days',
    data: '3GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'jio'
  },
  {
    id: 3,
    price: 449,
    validity: '56 days',
    data: '2GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'bsnl'
  },
  {
    id: 4,
    price: 599,
    validity: '84 days',
    data: '2GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'airtel'
  },
  {
    id: 5,
    price: 719,
    validity: '84 days',
    data: '3GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'jio'
  },
  {
    id: 6,
    price: 999,
    validity: '84 days',
    data: '6GB/day',
    description: 'Unlimited calls, 100 SMS/day',
    operator: 'bsnl'
  }
];

export const operators = [
  { 
    id: 'airtel', 
    name: 'Airtel', 
    color: 'red',
    prefixes: ['90', '91', '92', '93', '94', '95', '96', '97', '98', '99'] 
  },
  { 
    id: 'jio', 
    name: 'Jio', 
    color: 'blue',
    prefixes: ['70', '71', '72', '73', '74', '75', '76', '77', '78', '79'] 
  },
  { 
    id: 'bsnl', 
    name: 'BSNL', 
    color: 'green',
    prefixes: ['60', '61', '62', '63', '64', '65', '66', '67', '68', '69'] 
  }
];
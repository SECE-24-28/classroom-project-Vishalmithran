import React, { createContext, useContext, useState } from 'react';
import { rechargePlans as initialPlans } from '../data/plans';

const AppContext = createContext();

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [plans, setPlans] = useState(initialPlans);
  const [transactions, setTransactions] = useState([]);

  const login = (email, password) => {
    if (email === 'admin@recharge.com' && password === 'admin123') {
      setUser({ email, role: 'admin' });
      setIsLoggedIn(true);
      setIsAdmin(true);
      return true;
    } else if (email && password) {
      setUser({ email, role: 'user' });
      setIsLoggedIn(true);
      setIsAdmin(false);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsLoggedIn(false);
    setIsAdmin(false);
    window.location.href = '/';
  };

  const addTransaction = (transaction) => {
    const newTransaction = {
      ...transaction,
      id: Date.now(),
      timestamp: new Date().toISOString(),
      status: 'completed'
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const addPlan = (plan) => {
    const newPlan = { ...plan, id: Date.now() };
    setPlans(prev => [...prev, newPlan]);
  };

  const updatePlan = (id, updatedPlan) => {
    setPlans(prev => prev.map(plan => plan.id === id ? { ...plan, ...updatedPlan } : plan));
  };

  const deletePlan = (id) => {
    setPlans(prev => prev.filter(plan => plan.id !== id));
  };

  return (
    <AppContext.Provider value={{
      user, isLoggedIn, isAdmin, plans, transactions,
      login, logout, addTransaction, addPlan, updatePlan, deletePlan
    }}>
      {children}
    </AppContext.Provider>
  );
};